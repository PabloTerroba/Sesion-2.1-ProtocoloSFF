﻿using CodecLibrary;
using CodecLibrary.Codecs;
using CodecLibrary.Handlers;
using CodecLibrary.Messages;
using CodecLibrary.StateMachine;
using System;
using System.Net.Sockets;

public class WaitingForRequestState : ReceiverState
{
    private PacketBinaryCodec _codec = new PacketBinaryCodec();
    public WaitingForRequestState(Receiver receiver) : base(receiver)
    {
    }

    public override void HandleEvents()
    {
        base.HandleEvents();
    }
    protected override Packet Receive()
    {
        byte[] packetBytes = null;
        packetBytes = _receiver.ReceivePacket();
        Packet packet = _codec.Decode(packetBytes);// Esto es lo que no sé
        return packet;
    }
}
