﻿using CodecLibrary;
using CodecLibrary.Codecs;
using CodecLibrary.Handlers;
using CodecLibrary.Messages;
using CodecLibrary.StateMachine;
using System;
using System.IO;
using System.Net.Sockets;

public class ReceivingFileState : ReceiverState
{
    private FileStream _fileStream;
    private PacketBinaryCodec _codec = new PacketBinaryCodec();

    public ReceivingFileState(Receiver receiver) : base(receiver)
    {
    }

    public override void HandleEvents()
    {
        base.HandleEvents();
    }

    protected override Packet Receive()
    {
        byte[] packetBytes = _receiver.ReceivePacket();
        Packet packet = _codec.Decode(packetBytes);
        return packet;
    }

}
