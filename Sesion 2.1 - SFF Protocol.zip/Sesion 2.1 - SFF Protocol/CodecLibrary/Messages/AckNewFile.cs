﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodecLibrary.Messages
{
    class AckNewFile : Packet
    {
        public int SequenceNumber { get; private set; }
        public string FileName { get; private set; }

        public AckNewFile(int sequenceNumber, string fileName) : base(PacketBodyType.AckNewFile, 0, null)
        {
            SequenceNumber = sequenceNumber;
            FileName = fileName;
        }
    }
}
