﻿using System;
using System.IO;
using System.Net.Sockets;
using CodecLibrary;

public class Client
{
    private const string ServerIP = "127.0.0.1"; // IP del servidor
    private const int ServerPort = 9000;        // Puerto del servidor
    private const string FileName = "example.txt"; // Nombre del archivo a enviar

    private UdpClient _udpClient;
    private Sender _sender;

    public Client()
    {
        // Inicializar UdpClient y conectarlo al servidor
        _udpClient = new UdpClient();
        _udpClient.Connect(ServerIP, ServerPort);

        // Crear el objeto Sender con el archivo a enviar
        _sender = new Sender(_udpClient, FileName, ServerIP, ServerPort);
    }

    public void Start()
    {
        try
        {
            Console.WriteLine($"Enviando archivo '{FileName}' al servidor {ServerIP}:{ServerPort}...");

            // Iniciar la transferencia utilizando la lógica de estados
            _sender.HandleEvents();

            System.Threading.Thread.Sleep(1000);

            Console.WriteLine("Transferencia completada.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error durante la transferencia: {ex.Message}");
        }
        finally
        {
            _udpClient.Close();
            Console.WriteLine("Conexión cerrada.");
        }
    }

    public static void Main(string[] args)
    {
        // Verificar si el archivo existe en el directorio actual
        if (!File.Exists(FileName))
        {
            Console.WriteLine($"Error: El archivo '{FileName}' no existe en el directorio actual.");
            return;
        }

        // Crear e iniciar el cliente
        Client client = new Client();
        client.Start();

        Console.WriteLine("Presione cualquier tecla para salir...");
        Console.ReadKey();
    }
}




/*
using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Linq;
using CodecLibrary;

public class Client
{
    private const string ServerIP = "127.0.0.1"; // IP del servidor
    private const int ServerPort = 9000;
    private UdpClient _udpClient;
    private Sender _sender;

    public Client(string filePath)
    {
        _udpClient = new UdpClient();
        _udpClient.Connect(ServerIP, ServerPort);

        _sender = new Sender(_udpClient, filePath, ServerIP, ServerPort);
    }

    public void Start()
    {
        string fileName = _sender.GetFilePath().Split('\\').Last();
        Console.WriteLine($"Enviando archivo '{fileName}' al servidor {ServerIP}:{ServerPort}...");
        _sender.HandleEvents();
    }

    public static void Main(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Uso: Client <ruta_del_archivo>");
            return;
        }

        string filePath = args[0];

        if (!File.Exists(filePath))
        {
            Console.WriteLine($"Error: El archivo '{filePath}' no existe.");
            return;
        }

        Client client = new Client(filePath);
        client.Start();
    }
}
*/
